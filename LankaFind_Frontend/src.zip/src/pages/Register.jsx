import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useLanguage } from '../context/LanguageContext';

function Register() {
  const { t } = useLanguage();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState(''); // success message from backend
  const [error, setError] = useState('');     // error message, if any

  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setMessage('');
    setError('');

    try {
      // Send registration data to the backend
      const response = await api.post('/auth/register', {
        name,
        email,
        password
      });

      // Show the success message
      setMessage(response.data.msg);

      // Redirect to the login page after 2 seconds
      setTimeout(() => {
        navigate('/login');
      }, 2000);

    } catch (err) {
      // Show whatever error the backend returned (e.g. email already registered)
      if (err.response && err.response.data) {
        setError(err.response.data.msg);
      } else {
        setError(t('serverErrorRetry'));
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-950 transition-colors flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm dark:shadow-black/20 border border-gray-100 dark:border-slate-800">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight">
            {t('createAccount')}
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
            {t('registerSubtitle')}
          </p>
        </div>

        {/* Alert messages */}
        {message && <div className="mb-4 p-3 bg-green-100 dark:bg-emerald-500/10 text-green-700 dark:text-emerald-300 text-sm rounded-xl text-center font-medium">{message}</div>}
        {error && <div className="mb-4 p-3 bg-red-100 dark:bg-red-500/10 text-red-700 dark:text-red-300 text-sm rounded-xl text-center font-medium">{error}</div>}

        {/* Register form */}
        <form onSubmit={handleRegister} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelFullName')}</label>
            <input 
              type="text" 
              placeholder="John Doe" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelEmail')}</label>
            <input 
              type="email" 
              placeholder="name@example.com" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelPassword')}</label>
            <input 
              type="password" 
              placeholder="Minimum 6 characters" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
              required
            />
          </div>

          <button 
            type="submit" 
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-500 dark:to-amber-500 text-white font-semibold py-3 rounded-xl hover:opacity-90 shadow-md transition mt-2"
          >
            {t('createAccountBtn')}
          </button>
        </form>

        {/* Footer link */}
        <p className="text-center text-sm text-gray-600 dark:text-gray-400 mt-8">
          {t('haveAccount')}{' '}
          <Link to="/login" className="font-semibold text-blue-600 dark:text-amber-400 hover:underline">
            {t('loginHere')}
          </Link>
        </p>

      </div>
    </div>
  );
}

export default Register;
