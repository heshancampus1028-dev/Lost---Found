import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';
import ItemCard from '../components/ItemCard';
import SearchFilterBar from '../components/SearchFilterBar';
import { useLanguage } from '../context/LanguageContext';

function Home() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  // Search + filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All'); // All / lost / found

  // Re-fetch the bulletin feed whenever search/filter changes (debounced)
  useEffect(() => {
    const timer = setTimeout(() => {
      const fetchItems = async () => {
        setLoading(true);
        try {
          const params = {};
          if (searchTerm) params.search = searchTerm;
          if (filterCategory !== 'All') params.category = filterCategory;
          if (filterStatus !== 'All') params.status = filterStatus;

          const response = await api.get('/items', { params });
          setItems(response.data);
          setLoading(false);
        } catch (err) {
          console.error("Error fetching items:", err);
          setLoading(false);
        }
      };
      fetchItems();
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, filterCategory, filterStatus]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 py-12 bg-gray-50 dark:bg-slate-950 transition-colors">
      {/* Hero */}
      <div className="text-center max-w-2xl mb-12">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 dark:text-white tracking-tight mb-4">
          {t('homeWelcome')} <span className="text-blue-600 dark:text-blue-400">Lanka</span><span className="text-amber-500 dark:text-amber-400">Find</span>
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          {t('homeSubtitle')}
        </p>
      </div>

      {/* Main action cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 w-full max-w-4xl mb-16">
        
        {/* LOST ITEMS BUTTON CARD */}
        <button 
          onClick={() => navigate('/lost')}
          className="group bg-white dark:bg-slate-900 border-2 border-red-100 dark:border-red-500/20 hover:border-red-400 dark:hover:border-red-400/60 p-8 rounded-2xl shadow-sm hover:shadow-xl dark:shadow-black/20 transition-all duration-300 text-center flex flex-col items-center transform hover:-translate-y-1"
        >
          <div className="w-16 h-16 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">{t('homeLostCardTitle')}</h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            {t('homeLostCardDesc')}
          </p>
          <span className="mt-4 inline-flex items-center text-red-600 dark:text-red-400 font-semibold group-hover:translate-x-1 transition-transform">
            {t('homeLostCardCta')}
          </span>
        </button>

        {/* FOUND ITEMS BUTTON CARD */}
        <button 
          onClick={() => navigate('/found')}
          className="group bg-white dark:bg-slate-900 border-2 border-green-100 dark:border-emerald-500/20 hover:border-green-400 dark:hover:border-emerald-400/60 p-8 rounded-2xl shadow-sm hover:shadow-xl dark:shadow-black/20 transition-all duration-300 text-center flex flex-col items-center transform hover:-translate-y-1"
        >
          <div className="w-16 h-16 bg-green-100 dark:bg-emerald-500/10 text-green-600 dark:text-emerald-400 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">{t('homeFoundCardTitle')}</h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            {t('homeFoundCardDesc')}
          </p>
          <span className="mt-4 inline-flex items-center text-green-600 dark:text-emerald-400 font-semibold group-hover:translate-x-1 transition-transform">
            {t('homeFoundCardCta')}
          </span>
        </button>

      </div>

      {/* Bulletin feed section */}
      <div className="w-full max-w-4xl">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">{t('homeFeedTitle')}</h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm">{t('homeFeedSubtitle')}</p>
        </div>

        {/* Search + Category filter + Status toggle */}
        <SearchFilterBar
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          category={filterCategory}
          onCategoryChange={setFilterCategory}
          accentColor="blue"
        />
        <div className="flex gap-2 mb-6">
          {['All', 'lost', 'found'].map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition ${
                filterStatus === s
                  ? 'bg-blue-600 dark:bg-blue-500 text-white'
                  : 'bg-white dark:bg-slate-900 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-400'
              }`}
            >
              {s === 'All' ? t('statusAll') : s === 'lost' ? t('statusLost') : t('statusFound')}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center text-gray-500 dark:text-gray-400 py-8 font-medium">{t('loadingItems')}</div>
        ) : items.length === 0 ? (
          <div className="text-center text-gray-400 dark:text-gray-500 py-8 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-gray-200 dark:border-slate-700">
            {t('noItemsMatch')}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {items.map((item) => (
              <ItemCard key={item._id} item={item} />
            ))}
          </div>
        )}
      </div>

    </div>
  );
}

export default Home;
