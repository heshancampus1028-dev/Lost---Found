import React, { useState, useEffect } from 'react';
import api from '../api/axios';
import ItemCard from '../components/ItemCard';
import { useLanguage } from '../context/LanguageContext';

// Shows the reports the logged-in user has posted, and lets them
// toggle resolved/unresolved or delete a report.
function MyReports() {
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchMyItems = async () => {
    try {
      const response = await api.get('/items/my');
      setItems(response.data);
      setLoading(false);
    } catch (err) {
      console.error("Error fetching my items:", err);
      setError(t('loadReportsFailed'));
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyItems();
  }, []);

  // Toggle resolved / unresolved
  const handleToggleResolve = async (id) => {
    try {
      const response = await api.patch(`/items/${id}/resolve`);
      setItems(items.map((item) => (item._id === id ? response.data.item : item)));
    } catch (err) {
      console.error("Error updating item:", err);
      alert(t('updateFailed'));
    }
  };

  // Delete a report
  const handleDelete = async (id) => {
    if (!window.confirm(t('confirmDelete'))) return;

    try {
      await api.delete(`/items/${id}`);
      setItems(items.filter((item) => item._id !== id));
    } catch (err) {
      console.error("Error deleting item:", err);
      alert(t('deleteFailed'));
    }
  };

  const activeItems = items.filter((item) => !item.resolved);
  const resolvedItems = items.filter((item) => item.resolved);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-950 transition-colors pt-24 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-10">

        <div>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t('myReportsTitle')}</h1>
          <p className="text-gray-500 dark:text-gray-400 text-sm">{t('myReportsSubtitle')}</p>
        </div>

        {error && <div className="p-3 bg-red-100 dark:bg-red-500/10 text-red-700 dark:text-red-300 text-sm rounded-xl text-center font-medium">{error}</div>}

        {loading ? (
          <div className="text-center text-gray-500 dark:text-gray-400 py-12">{t('loadingItems')}</div>
        ) : items.length === 0 ? (
          <div className="text-center text-gray-400 dark:text-gray-500 py-12 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-gray-200 dark:border-slate-700">
            {t('noReportsYet')}
          </div>
        ) : (
          <>
            <div>
              <h2 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4">{t('activeReports')} ({activeItems.length})</h2>
              {activeItems.length === 0 ? (
                <p className="text-gray-400 dark:text-gray-500 text-sm">{t('noActiveReports')}</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeItems.map((item) => (
                    <ItemCard
                      key={item._id}
                      item={item}
                      showActions
                      onToggleResolve={handleToggleResolve}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              )}
            </div>

            {resolvedItems.length > 0 && (
              <div>
                <h2 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4">{t('resolvedReports')} ({resolvedItems.length})</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {resolvedItems.map((item) => (
                    <ItemCard
                      key={item._id}
                      item={item}
                      showActions
                      onToggleResolve={handleToggleResolve}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default MyReports;
