import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import ItemCard from '../components/ItemCard';
import SearchFilterBar from '../components/SearchFilterBar';

function FoundItems() {
  const { isAuthenticated } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  // Form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [contact, setContact] = useState('');

  // Items fetched from the database
  const [foundItemsList, setFoundItemsList] = useState([]);
  const [loading, setLoading] = useState(true);

  // Search + filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');

  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Re-fetch items whenever search/filter changes (debounced)
  useEffect(() => {
    const timer = setTimeout(() => {
      const fetchFoundItems = async () => {
        setLoading(true);
        try {
          const params = { status: 'found' };
          if (searchTerm) params.search = searchTerm;
          if (filterCategory !== 'All') params.category = filterCategory;

          const response = await api.get('/items', { params });
          setFoundItemsList(response.data);
          setLoading(false);
        } catch (err) {
          console.error("Error fetching found items:", err);
          setLoading(false);
        }
      };
      fetchFoundItems();
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, filterCategory]);

  // Submit a new found item report
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!title || !category || !location || !contact) return;

    setMessage('');
    setError('');

    try {
      const response = await api.post('/items', {
        title,
        description,
        status: 'found',
        location,
        contact,
        category
      });

      setMessage(response.data.msg);
      setFoundItemsList([response.data.item, ...foundItemsList]);

      // Clear the form
      setTitle('');
      setCategory('');
      setLocation('');
      setDescription('');
      setContact('');

    } catch (err) {
      console.error("Error posting found item:", err);
      if (err.response && err.response.status === 401) {
        setError(t('sessionExpired'));
      } else {
        setError(t('postFailed'));
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-950 transition-colors pt-24 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Report form */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm dark:shadow-black/20 border border-gray-100 dark:border-slate-800 h-fit">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
            {t('reportFoundTitle')}
          </h2>

          {!isAuthenticated && (
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 text-sm rounded-xl text-center font-medium">
              {t('loginToReportPrompt')}
            </div>
          )}

          {message && <div className="mb-4 p-3 bg-green-100 dark:bg-emerald-500/10 text-green-700 dark:text-emerald-300 text-sm rounded-xl text-center font-medium">{message}</div>}
          {error && <div className="mb-4 p-3 bg-red-100 dark:bg-red-500/10 text-red-700 dark:text-red-300 text-sm rounded-xl text-center font-medium">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelItemTitle')}</label>
              <input 
                type="text" 
                placeholder={t('placeholderFoundTitle')} 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelCategory')}</label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition bg-white"
                required
              >
                <option value="">{t('selectCategory')}</option>
                <option value="Electronics">{t('categoryElectronics')}</option>
                <option value="Documents">{t('categoryDocuments')}</option>
                <option value="Personal Items">{t('categoryPersonalItems')}</option>
                <option value="Keys">{t('categoryKeys')}</option>
                <option value="Other">{t('categoryOther')}</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelFoundLocation')}</label>
              <input 
                type="text" 
                placeholder={t('placeholderFoundLocation')} 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelContact')}</label>
              <input 
                type="tel" 
                placeholder={t('placeholderContact')} 
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('labelDescription')}</label>
              <textarea 
                rows="3" 
                placeholder={t('placeholderFoundDescription')} 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 transition resize-none"
              ></textarea>
            </div>

            <button 
              type="submit" 
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 dark:from-emerald-500 dark:to-amber-500 text-white font-semibold py-2.5 rounded-xl hover:opacity-90 shadow-md transition"
            >
              {isAuthenticated ? t('publishReport') : t('loginToPublish')}
            </button>
          </form>
        </div>

        {/* Feed */}
        <div className="lg:col-span-2 space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t('recentFoundReports')}</h1>
            <p className="text-gray-500 dark:text-gray-400 text-sm">{t('recentFoundSubtitle')}</p>
          </div>

          <SearchFilterBar
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            category={filterCategory}
            onCategoryChange={setFilterCategory}
            accentColor="emerald"
          />

          {loading ? (
            <div className="text-center text-gray-500 dark:text-gray-400 py-12">{t('loadingItems')}</div>
          ) : foundItemsList.length === 0 ? (
            <div className="text-center text-gray-400 dark:text-gray-500 py-12 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-gray-200 dark:border-slate-700">
              {t('noFoundMatch')}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {foundItemsList.map((item) => (
                <ItemCard key={item._id} item={item} />
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

export default FoundItems;
