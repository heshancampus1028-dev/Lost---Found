import React from 'react';
import { useLanguage } from '../context/LanguageContext';

// Category *values* stay in English since they must match the backend enum exactly.
// Only the *displayed label* is translated.
const CATEGORY_VALUES = ['All', 'Electronics', 'Documents', 'Personal Items', 'Keys', 'Other'];
const CATEGORY_LABEL_KEYS = {
  All: 'allCategories',
  Electronics: 'categoryElectronics',
  Documents: 'categoryDocuments',
  'Personal Items': 'categoryPersonalItems',
  Keys: 'categoryKeys',
  Other: 'categoryOther',
};

// Search input + Category dropdown - reused across the Home/Lost/Found pages
function SearchFilterBar({ searchTerm, onSearchChange, category, onCategoryChange, accentColor = 'blue' }) {
  const { t } = useLanguage();

  const ringClass = {
    blue: 'focus:ring-blue-500 dark:focus:ring-blue-400',
    red: 'focus:ring-red-500 dark:focus:ring-red-400',
    emerald: 'focus:ring-emerald-500 dark:focus:ring-emerald-400'
  }[accentColor] || 'focus:ring-blue-500 dark:focus:ring-blue-400';

  return (
    <div className="flex flex-col sm:flex-row gap-3 mb-6">
      <div className="relative flex-grow">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500">🔍</span>
        <input
          type="text"
          placeholder={t('searchPlaceholder')}
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className={`w-full pl-10 pr-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 ${ringClass} transition bg-white dark:bg-slate-900 text-gray-800 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500`}
        />
      </div>

      <select
        value={category}
        onChange={(e) => onCategoryChange(e.target.value)}
        className={`px-4 py-2.5 border border-gray-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 ${ringClass} transition bg-white dark:bg-slate-900 text-gray-800 dark:text-gray-100 sm:w-56`}
      >
        {CATEGORY_VALUES.map((c) => (
          <option key={c} value={c}>
            {t(CATEGORY_LABEL_KEYS[c])}
          </option>
        ))}
      </select>
    </div>
  );
}

export default SearchFilterBar;
