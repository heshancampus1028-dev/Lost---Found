import React from 'react';
import { useLanguage } from '../context/LanguageContext';

// Reusable card component for displaying a Lost/Found item
// showActions=true (used on the My Reports page) shows Resolve/Delete buttons
function ItemCard({ item, showActions = false, onToggleResolve, onDelete }) {
  const { t } = useLanguage();
  const isLost = item.status === 'lost';

  return (
    <div
      className={`bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm dark:shadow-black/20 border flex flex-col justify-between hover:shadow-md dark:hover:border-amber-500/40 transition-colors ${
        item.resolved ? 'border-gray-100 dark:border-slate-700 opacity-60' : 'border-gray-100 dark:border-slate-700'
      }`}
    >
      <div>
        <div className="flex justify-between items-start mb-2 gap-2">
          <span
            className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
              isLost
                ? 'bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 border border-red-100 dark:border-red-500/30'
                : 'bg-green-50 dark:bg-emerald-500/10 text-green-600 dark:text-emerald-400 border border-green-100 dark:border-emerald-500/30'
            }`}
          >
            {isLost ? t('badgeLost') : t('badgeFound')}
          </span>
          {item.resolved && (
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-amber-400 border border-gray-200 dark:border-amber-500/30">
              {t('badgeResolved')}
            </span>
          )}
          <span className="text-xs text-gray-400 dark:text-gray-500 ml-auto">
            {new Date(item.createdAt).toLocaleDateString()}
          </span>
        </div>

        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-1">{item.title}</h3>
        {item.category && (
          <span className="inline-block text-xs font-medium text-gray-500 dark:text-amber-300 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-full px-2 py-0.5 mb-2">
            {item.category}
          </span>
        )}
        <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1 mb-2">
          📍 <span className="font-medium text-gray-600 dark:text-gray-300">{item.location}</span>
        </p>
        <p className="text-gray-600 dark:text-gray-300 text-sm line-clamp-3">{item.description}</p>
      </div>

      <div className="mt-4 pt-3 border-t border-gray-50 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
        <span className="text-blue-600 dark:text-blue-400 font-medium">📞 {item.contact}</span>

        {showActions && (
          <div className="flex gap-3">
            <button
              onClick={() => onToggleResolve(item._id)}
              className="font-semibold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 transition"
            >
              {item.resolved ? t('markUnresolved') : t('markResolved')}
            </button>
            <button
              onClick={() => onDelete(item._id)}
              className="font-semibold text-red-500 dark:text-red-400 hover:text-red-600 dark:hover:text-red-300 transition"
            >
              {t('deleteBtn')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default ItemCard;
