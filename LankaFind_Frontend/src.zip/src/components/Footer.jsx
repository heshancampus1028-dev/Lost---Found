import React from 'react';
import { useLanguage } from '../context/LanguageContext';

function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="bg-white dark:bg-slate-900 border-t border-gray-200 dark:border-amber-500/20 py-6 mt-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-500 dark:text-gray-400">
        &copy; {new Date().getFullYear()} LankaFind. {t('footerRights')}
      </div>
    </footer>
  );
}

export default Footer;
