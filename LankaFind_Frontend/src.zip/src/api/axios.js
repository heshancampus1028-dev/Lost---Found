import axios from 'axios';

// Backend base URL defined in one place
// (replace with an environment variable when deploying to production)
const API_BASE_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL
});

// Attach the auth token to every outgoing request, if one is stored
// (needed for routes that require the user to be logged in)
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
